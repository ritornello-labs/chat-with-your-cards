# @elvis-labs/interaction-schema

The presentation standard for Elvis Labs interaction cards: a versioned,
semantic block tree plus the action/event vocabulary a renderer emits back.
This package is deliberately small and stable: plain TypeScript types, a JSON
Schema, and dependency-free runtime validators. It has **zero runtime
dependencies** and imports neither React nor the DOM.

What this package intentionally does **not** contain: how a card came to
exist, what happens after a button press, who is allowed to press it, or how
documents move between processes. Hosts own all of that and hand renderers a
finished `InteractionPresentation`.

## The model

```ts
import { validatePresentation, type InteractionPresentation } from "@elvis-labs/interaction-schema";

const card: InteractionPresentation = {
  version: "1.0",
  interactionId: "int_9d3c",       // opaque
  revision: "2",                    // opaque
  digest: "sha256:…",               // opaque
  eyebrow: "anki.note.create",
  title: "Create Anki note",
  summary: "A reviewed vocabulary note.",
  badge: { label: "Awaiting review" },
  blocks: [
    { type: "field_set", fields: [{ name: "Front", new: "妥协" }] },
    { type: "card_preview", ref: "preview:mandarin-1" },
  ],
  actions: [
    { id: "approve", intent: "approve", label: "Add note" },
    { id: "revise", intent: "revise", label: "Edit" },
    { id: "reject", intent: "reject", label: "Reject" },
  ],
  revisionLabel: "Revision 2",
};
```

- **Opaque identifiers.** `interactionId`, `revision`, `digest`, and action
  ids mean nothing to a renderer. It may use them for identity/keying and must
  echo them **byte-for-byte** in `PresentationActionEvent` /
  `PresentationReviseEvent`; it never parses, orders, or gates on them.
- **The host decides actionability.** `actions` lists exactly the buttons the
  host currently offers; an empty list renders a read-only card. Renderers do
  not decide whether a card is stale, resolved, or actionable by this user.
- **Display text is final.** `badge.label`, `revisionLabel`, and `eyebrow`
  arrive as finished strings; renderers add no vocabulary of their own.
- **Nothing runnable.** A block tree carries meaning, not commands, markup,
  or callbacks.

## Block vocabulary (schema 1.0)

Core, domain-neutral: `text`, `evidence`, `result`, `key_value`, `field_set`,
`warning`, `json`, `diff`, `progress`, `form`.

App-specific blocks live behind the **extension namespace**: a block type
matching `x-<namespace>.<name>` (for example `x-anki.card_preview`), carrying
arbitrary JSON data plus an optional `fallback` string. Renderers that do not
recognize an extension must show the fallback (or a readable placeholder
naming the type) — never run it, never hide it silently.

`card_preview` is the one **grandfathered alias**: it predates the extension
namespace and is kept in 1.x for wire compatibility as an alias of
`x-anki.card_preview` (`{ type: "card_preview", ref: string }`, where `ref`
is an opaque host-owned preview reference). New app-specific blocks must use
the `x-` namespace; a future 2.0 may retire the bare alias.

## Version policy

- Every block tree carries an explicit `version` (currently `"1.0"`), which is
  the version of this **standard**, independent of the package's semver.
- Within major version 1, changes are additive only: new optional properties
  or new block types. Anything a 1.0 renderer already accepts stays valid.
- Removing or reshaping existing vocabulary requires `version: "2.0"` and a
  new major package release.
- Validators accept unknown `x-*` extension types by design and reject unknown
  bare types, so additive core growth is an explicit, versioned decision.

### Renderer compatibility

A renderer declares the standard-version range it supports.
`@elvis-labs/interaction-ui-react` 0.2.x renders `version >= 1.0, < 2.0` and
falls back readably for extension blocks it does not recognize.

| Package | Standard versions rendered |
| --- | --- |
| `@elvis-labs/interaction-ui-react` 0.2.x | 1.x |

## Validation

`validatePresentation(value)` returns `{ ok, errors }` with every structural
problem found; `isInteractionPresentation(value)` is the type-guard flavor.
The equivalent JSON Schema ships at
`schemas/interaction-presentation-1.schema.json`.

## Distribution

Consumed as a committed `npm pack` tarball or a git tag; not published to
public npm.
