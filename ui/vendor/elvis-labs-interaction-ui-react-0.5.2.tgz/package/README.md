# @elvis-labs/interaction-ui-react

Presentational React renderer for the interaction presentation standard
defined by [`@elvis-labs/interaction-schema`](../interaction-schema/README.md).
Props in, events out — nothing else.

- **Depends only on** `@elvis-labs/interaction-schema`; React is a peer
  dependency. No network, storage, or workflow code loads with this package.
- **Supported standard versions:** `>= 1.0, < 2.0` (see the schema README's
  compatibility table).
- **Opaque identifiers.** `interactionId`, `revision`, `digest`, and action
  ids are echoed **byte-for-byte** in `onAction`/`onRevise` events. The
  renderer uses them only for element keys and draft-reset identity; it never
  decides whether a revision is stale or an action is allowed — hosts do that
  by choosing which `actions` to pass.

```tsx
import { InteractionCard } from "@elvis-labs/interaction-ui-react";
import "@elvis-labs/interaction-ui-react/styles.css";

<InteractionCard
  interaction={presentation}          // InteractionPresentation
  busy={busy}
  error={errorText}
  onAction={({ interactionId, revision, digest, actionId }) => …}
  onRevise={({ interactionId, revision, digest, fields }) => …}
  renderBlock={(block) => block.type === "card_preview" ? <MyPreview/> : undefined}
/>
```

Behavior notes:

- An action with intent `revise` switches the card's `field_set` into
  editable textareas (when `onRevise` is provided); **Save revision** emits
  `onRevise` with the drafted `fields`, and Cancel restores the rendered
  values. The card resets its draft whenever `interactionId`/`revision`
  change identity.
- An empty `actions` list renders a read-only card with no footer.
- `card_preview` (and its namespaced form `x-anki.card_preview`) renders a
  placeholder unless the host overrides it via `renderBlock`. Unrecognized
  `x-*` extension blocks render their `fallback` text or a readable
  "Unsupported content" placeholder — never nothing.
- The visual design (styles.css) is unchanged from `@elvis-labs/interaction-ui`
  0.1.0 apart from class names for badge tones (`eui-tone-*` instead of
  lifecycle-named classes).

Distribution: committed `npm pack` tarball or git tag; not published to
public npm.
